************************************************
IMPORTANT
************************************************

************************************************ 
INSTALLATION
************************************************

Please read the first chapter of the documentation PDF named
"TanksMultiplayer" for further information about this asset and
its installation guide. The PDF file is included in this package.
(THIS ASSET WILL NOT WORK WITHOUT DOING THE INITIAL SETUP!)

For a video tutorial, visit our YouTube channel:
https://www.youtube.com/user/ReboundGamesTV

************************************************ 
SUPPORT
************************************************ 

For support queries please visit our support forum, our thread
on the Unity forums, or drop us a line. The corresponding links
are located in the top menu under:
Window > Tanks Multiplayer > About.